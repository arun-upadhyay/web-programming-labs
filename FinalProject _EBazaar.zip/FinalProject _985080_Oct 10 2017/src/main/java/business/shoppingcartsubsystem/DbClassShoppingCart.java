package business.shoppingcartsubsystem;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.LinkedList;
import java.util.List;
import java.util.logging.Logger;

import static business.util.StringParse.*;

import business.*;
import business.externalinterfaces.ICartItem;
import business.externalinterfaces.ICustomerProfile;
import middleware.DatabaseException;
import middleware.DbConfigProperties;
import middleware.dataaccess.DataAccessSubsystemFacade;
import middleware.externalinterfaces.IDataAccessSubsystem;
import middleware.externalinterfaces.IDbClass;
import middleware.externalinterfaces.DbConfigKey;

public class DbClassShoppingCart implements IDbClass {
	private static final Logger LOG = Logger
			.getLogger(DbClassShoppingCart.class.getPackage().getName());
	private IDataAccessSubsystem dataAccessSS = new DataAccessSubsystemFacade();
	IDataAccessSubsystem dataAccess;
	ShoppingCart cart;
	List<ICartItem> cartItemsList;
	ICustomerProfile custProfile;
	Integer cartId;
	String query;
	final String GET_ID = "GetId";
	final String GET_SAVED_ITEMS = "GetSavedItems";
	String queryType;

	ICartItem item;
	ICartItem itemData;

	final String SAVED_CART = "SavedCart";
	final String SAVED_CART_ITEMS = "SavedCartItems";

	public void buildQuery() {
		if (queryType.equals(GET_ID)) {
			buildGetIdQuery();
		} else if (queryType.equals(GET_SAVED_ITEMS)) {
			buildGetSavedItemsQuery();
		} else if (queryType.equals(SAVED_CART)) {
			buildSaveQueryShoppingCart();
		} else if (queryType.equals(SAVED_CART_ITEMS)) {
			// buildSaveQueryShoppingCartItemList();
		} else if (queryType.equals(itemData.toString())) {
			buildSaveQueryShoppingCartItemList(itemData);
		}

	}

	// save shopping cart details
	private void buildSaveQueryShoppingCart() {
		query = "INSERT INTO ShopCartTbl(custid) VALUES('"
				+ custProfile.getCustId() + "')";

	}

	// save shopping cart item with CartID
	private void buildSaveQueryShoppingCartItemList(ICartItem item) {
		// for (ICartItem item : cartItemsList) {
		// implement dume data like Tax
		query = "INSERT INTO shopcartitem (shopcartid,productid,quantity,totalprice,shipmentcost,taxamount) VALUES('"
				+ cartId
				+ "','"
				+ item.getProductid()
				+ "','"
				+ item.getQuantity()
				+ "','"
				+ item.getTotalprice()
				+ "','"
				+ 7.5
				+ "','"
				+ Double.parseDouble(item.getTotalprice())
				/ 100
				* 7.5 + "')";
		// }
	}

	private void buildGetIdQuery() {
		query = "SELECT shopcartid " + "FROM ShopCartTbl " + "WHERE custid = "
				+ custProfile.getCustId();

	}

	private void buildGetSavedItemsQuery() {
		// IMPLEMENT
		query = "";

	}

	// saveShoppingCart
	public void saveShoppingCart(ICustomerProfile custProfile)
			throws DatabaseException {
		this.custProfile = custProfile;
		queryType = SAVED_CART;
		dataAccessSS.createConnection(this);
		dataAccessSS.save();
	}

	// save all Item with Shopping Cart ID
	public void saveShoppingCartAllItems(ICustomerProfile custProfile,
			Integer cartId, List<ICartItem> cartItemsList)
			throws DatabaseException {
		this.custProfile = custProfile;
		this.cartId = cartId;
		this.cartItemsList = cartItemsList;

		for (ICartItem item : cartItemsList) {
			itemData = item;
			queryType = itemData.toString();
			dataAccessSS.createConnection(this);
			dataAccessSS.saveWithinTransaction(this);
			// dataAccessSS.save();
		}
	}

	public Integer getShoppingCartId(ICustomerProfile custProfile)
			throws DatabaseException {
		this.custProfile = custProfile;
		queryType = GET_ID;
		dataAccessSS.createConnection(this);
		dataAccessSS.read();
		return cartId;
	}

	public List<ICartItem> getSavedCartItems(Integer cartId)
			throws DatabaseException {
		// IMPLEMENT
		return new LinkedList<ICartItem>();

	}

	public void populateEntity(ResultSet resultSet) throws DatabaseException {
		if (queryType.equals(GET_ID)) {
			populateShopCartId(resultSet);
		} else if (queryType.equals(GET_SAVED_ITEMS)) {
			populateCartItemsList(resultSet);
		}

	}

	private void populateShopCartId(ResultSet rs) {
		try {
			while (rs.next()) {
				cartId = rs.getInt("shopcartid");
			}
		} catch (SQLException e) {
			// do nothing
		}
	}

	private void populateCartItemsList(ResultSet rs) throws DatabaseException {
		// IMPLEMENT
		ICartItem cartItem = new CartItem("name", "1", "10");

		cartItemsList = new LinkedList<ICartItem>();
		cartItemsList.add(cartItem);

	}

	public String getDbUrl() {
		DbConfigProperties props = new DbConfigProperties();
		return props.getProperty(DbConfigKey.ACCOUNT_DB_URL.getVal());
	}

	public String getQuery() {
		return query;
	}
}
