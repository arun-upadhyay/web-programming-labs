
package business.externalinterfaces;


public interface ICreditCard {
    String getNameOnCard();
    String getExpirationDate();
    String getCardNum();
    String getCardType();

}
