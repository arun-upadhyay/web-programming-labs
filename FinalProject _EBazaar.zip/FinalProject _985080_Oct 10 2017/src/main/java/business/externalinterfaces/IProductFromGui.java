package business.externalinterfaces;

public interface IProductFromGui {
	   
	 public String getMfgDate();
	 public String getProductName();
	 public String getQuantityAvail();
	 public String getUnitPrice();
	    
}
