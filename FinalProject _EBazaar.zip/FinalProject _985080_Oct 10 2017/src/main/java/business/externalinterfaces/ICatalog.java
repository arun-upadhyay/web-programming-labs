package business.externalinterfaces;

public interface ICatalog {
	String getId();
	String getName();
	void setId(String id);
	void setName(String name);
}
