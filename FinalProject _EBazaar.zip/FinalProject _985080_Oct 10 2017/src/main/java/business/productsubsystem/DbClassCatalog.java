package business.productsubsystem;

import java.util.ArrayList;
import java.util.List;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Logger;

import business.externalinterfaces.ICatalog;

import middleware.DatabaseException;
import middleware.DbConfigProperties;
import middleware.dataaccess.DataAccessSubsystemFacade;
import middleware.dataaccess.DataAccessUtil;
import middleware.externalinterfaces.IDataAccessSubsystem;
import middleware.externalinterfaces.IDbClass;
import middleware.externalinterfaces.DbConfigKey;

public class DbClassCatalog implements IDbClass {
	private static final Logger LOG = Logger.getLogger(DbClassCatalog.class
			.getPackage().getName());
	private IDataAccessSubsystem dataAccessSS = new DataAccessSubsystemFacade();
	private String query;
	private String queryType;
	private final String SAVE = "Save";
	private final String READ = "Read";
	private final String READID = "ReadID";
	private ICatalog catalog;
	private final String CATALOGNAME = "catalogname";
	private final String CATALOGID = "catalogid";
	List<String[]> catList=new ArrayList<String[]>();
	private Integer catID;
	private String catalogID;

	public List<String[]> getCatLogList(){
		return catList;
	}
	public void saveNewCatalog(String name) throws DatabaseException {
		// IMPLEMENT
		queryType = SAVE;
		dataAccessSS.saveWithinTransaction(this);
	}

	public void readCatalogList() throws DatabaseException {
		queryType = READ;
		dataAccessSS.createConnection(this);
		dataAccessSS.read();
	}
	
	public void readCatalogID() throws DatabaseException {
		queryType = READID;
		dataAccessSS.createConnection(this);
		dataAccessSS.read();
	}


	public void buildQuery() throws DatabaseException {
		if (queryType.equals(SAVE)) {
			buildSaveQuery();
		} else if (queryType.equals(READ)) {
			buildReadQuery();
		}
		else if (queryType.equals(READID)) {
			buildReadQueryForCatalogID();
		}

	}

	void buildSaveQuery() throws DatabaseException {
		// IMPLEMENT
		query = "INSERT into CatalogType " + "(catalogid,catalogname) "
				+ "VALUES(NULL," + catalog.getName() + "')";
	}

	void buildReadQuery() {
		query = "SELECT catalogname from CatalogType";
	}
	
	void buildReadQueryForCatalogID() {
		query = "SELECT catalogid from CatalogType where catalogname='"+getCatalogID()+"'";
	}

	public String getDbUrl() {
		DbConfigProperties props = new DbConfigProperties();
		return props.getProperty(DbConfigKey.PRODUCT_DB_URL.getVal());
	}

	public String getQuery() {
		// IMPLEMENT
		return query;
	}

	public void populateEntity(ResultSet resultSet) throws DatabaseException {
		// do nothing
		if(queryType.equals(READ)){
			populateCatalog(resultSet);
    	}	
		else if(queryType.equals(READID)){
			populateID(resultSet);
    	}

	}
	 private void populateCatalog(ResultSet rs) throws DatabaseException {
	    	try {
	            while(rs.next()){
	            	catList.add(new String[]{rs.getString(CATALOGNAME)});
	            }           
	        }
	        catch(SQLException e) {
	            throw new DatabaseException(e);
	        }    	
	    }
	 
	 private void populateID(ResultSet rs) throws DatabaseException {
	    	try {
	            if(rs.next()){
	            	setCatID(rs.getInt(CATALOGID));
	            }           
	        }
	        catch(SQLException e) {
	            throw new DatabaseException(e);
	        }    	
	    }
	public String getCatalogID() {
		return catalogID;
	}
	public void setCatalogID(String catalogID) {
		this.catalogID = catalogID;
	}
	public Integer getCatID() {
		return catID;
	}
	public void setCatID(Integer catID) {
		this.catID = catID;
	}

}
