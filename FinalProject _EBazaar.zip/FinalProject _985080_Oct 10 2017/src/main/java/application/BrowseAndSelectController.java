package application;

import java.awt.Window;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.logging.Logger;

import javax.swing.JInternalFrame;
import javax.swing.JOptionPane;
import javax.swing.JTable;

import business.DbClassQuantity;
import business.Quantity;
import business.RuleException;
import business.RulesQuantity;
import business.SessionContext;

import business.externalinterfaces.CustomerConstants;
import business.externalinterfaces.ICartItem;
import business.externalinterfaces.ICustomerSubsystem;
import business.externalinterfaces.IProductFromDb;
import business.externalinterfaces.IProductSubsystem;
import business.externalinterfaces.IRules;
import business.externalinterfaces.IShoppingCart;
import business.externalinterfaces.IShoppingCartSubsystem;
import business.productsubsystem.ProductSubsystemFacade;
import business.shoppingcartsubsystem.ShoppingCartSubsystemFacade;
import business.util.ProductUtil;
import business.util.ShoppingCartUtil;
import business.util.StringParse;

import middleware.DatabaseException;
import middleware.EBazaarException;

import application.gui.CartItemsWindow;
import application.gui.CatalogListWindow;
import application.gui.DefaultData;
import application.gui.EbazaarMainFrame;
import application.gui.MaintainCatalogTypes;
import application.gui.MaintainProductCatalog;
import application.gui.ProductDetailsWindow;
import application.gui.ProductListWindow;
import application.gui.QuantityWindow;
import application.gui.SelectOrderWindow;

public class BrowseAndSelectController implements CleanupControl {
	
	private static final Logger LOG = Logger
			.getLogger("BrowseAndSelectController.class.getName()");

	// ///////// EVENT HANDLERS -- new code goes here ////////////
	String[] productParams=new String[9];
	// control of mainFrame
	class PurchaseOnlineActionListener implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			catalogListWindow = new CatalogListWindow();
			IProductSubsystem pss = new ProductSubsystemFacade();
			try {
				List<String[]> catalogNames = pss.getCatalogNames();
				catalogListWindow.updateModel(catalogNames);
				mainFrame.getDesktop().add(catalogListWindow);
				catalogListWindow.setVisible(true);
			} catch(DatabaseException ex) {
				String errMsg = "Database unavailable: " + ex.getMessage();
				JOptionPane.showMessageDialog(catalogListWindow, errMsg,
						"Error", JOptionPane.ERROR_MESSAGE);
			}
			
		}
	}

	class LoginListener implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			try {
				LoginControl loginControl = new LoginControl(mainFrame,
						mainFrame);
				loginControl.startLogin();
			} catch (Exception ex) {
				ex.printStackTrace();
			}
		}
	}

	class RetrieveCartActionListener implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			if(cartItemsWindow == null){
                cartItemsWindow = new  CartItemsWindow();
            }
			EbazaarMainFrame.getInstance().getDesktop().add(cartItemsWindow);
			cartItemsWindow.setVisible(true);
		}
	}

	// control of CatalogListWindow
	class SelectCatalogListener implements ActionListener {
		public void actionPerformed(ActionEvent evt) {
			JTable table = catalogListWindow.getTable();
			int selectedRow = table.getSelectedRow();
			if (selectedRow >= 0) {				
				String type = (String) table.getValueAt(selectedRow, 0);
				LOG.info("Selected type: " + type);
				catalogListWindow.setVisible(false);
				IProductSubsystem psss = new ProductSubsystemFacade();
				try {
					productListWindow  = new ProductListWindow(type);
					List<IProductFromDb> productNamesList = psss.getProductList(type);
					List<String[]> productList=new ArrayList<String[]>();
					for(IProductFromDb productName:productNamesList){
						productList.add(new String[]{productName.getProductName()});
						System.out.println(productName.getProductName());
					}
					productListWindow.updateModel(productList);
					mainFrame.getDesktop().add(productListWindow);
					productListWindow.setVisible(true);
				}
				catch(Exception e){
					String errMsg = "Database unavailable: " + e.getMessage();
					JOptionPane.showMessageDialog(productListWindow, errMsg,
							"Error", JOptionPane.ERROR_MESSAGE);
				}
				
			}
			// If arriving here, the value of selectedRow is -1,
			// which means no row was selected
			else {
				String errMsg = "Please select a row.";
				JOptionPane.showMessageDialog(catalogListWindow, errMsg,
						"Error", JOptionPane.ERROR_MESSAGE);
			}
		}

	}

	class BackToMainFrameListener implements ActionListener {
		public void actionPerformed(ActionEvent evt) {
			mainFrame.setVisible(true);
			catalogListWindow.setVisible(false);
		}
	}

	// Control of ProductListWindow
	class SelectProductListener implements ActionListener {
		HashMap<String, String[]> readProductDetailsData() {
			DefaultData productData = DefaultData.getInstance();
			return productData.getProductDetailsData();
		}

		boolean useDefaultData;

		public SelectProductListener(boolean useDefData) {
			//useDefaultData = useDefData;
		}

		/* Returns, as a String array, the product details based on the type */
		/*
		String[] readProductDetailsData(String type) {
			if (useDefaultData) {
				DefaultData productData = DefaultData.getInstance();
				return productData.getProductDetailsData(type);
			} 
			return null;
		}
		*/

		public void actionPerformed(ActionEvent evt) {
			JTable table = productListWindow.getTable();
			int selectedRow = table.getSelectedRow();

			if (selectedRow >= 0) {
				String type = (String) table.getValueAt(selectedRow, 0);
				IProductSubsystem iProductSub = new ProductSubsystemFacade();
				try{
					IProductFromDb productDetails=iProductSub.getProduct(type);
					System.out.println(productDetails.getProductId()+","+productDetails.getProductName());
					productParams[0]=productDetails.getProductName();
					productParams[1]=productDetails.getUnitPrice();
					productParams[2]=productDetails.getQuantityAvail();
					productParams[3]=productDetails.getDescription();
					//productParams = readProductDetailsData(type);
					productDetailsWindow = new ProductDetailsWindow(productParams);
					mainFrame.getDesktop().add(productDetailsWindow);
					productListWindow.setVisible(false);
					productDetailsWindow.setVisible(true);
				} catch (Exception e) {
					String errMsg = "Database unavailable: " + e.getMessage();
					JOptionPane.showMessageDialog(productDetailsWindow, errMsg,
							"Error", JOptionPane.ERROR_MESSAGE);
				}
				
			}
			// Value of selectedRow is -1, which means no row was selected
			else {
				String errMsg = "Please select a row.";
				JOptionPane.showMessageDialog(productListWindow, errMsg,
						"Error", JOptionPane.ERROR_MESSAGE);
			}
		}
	}

	class BackToCatalogListListener implements ActionListener {
		public void actionPerformed(ActionEvent evt) {
			catalogListWindow.setVisible(true);
			productListWindow.setVisible(false);
		}
	}

	// ///// control ProductDetails
	class AddCartItemListener implements ActionListener {
		public void actionPerformed(ActionEvent evt) {
			productDetailsWindow.setVisible(false);
			quantityWindow = new QuantityWindow(false, null);
			EbazaarMainFrame.getInstance().getDesktop().add(quantityWindow);
			quantityWindow.setVisible(true);
			quantityWindow.setParentWindow(productDetailsWindow);
		}
	}

	class QuantityOkListener implements ActionListener {

		public void actionPerformed(ActionEvent evt) {
			
			boolean rulesOk = true;
			//insert rules
        	//gather quantity data 
        	//   ... read quantity requested from window
        	//           --create instance of Quantity
			//String productName=productDetailsWindow.getName();
			
			String requestQuantity=quantityWindow.getQuantityDesired();
			 Quantity quantity=new Quantity(requestQuantity); 
			 
        	//   ... read quantity avail from database
        	//           -- uses DbClassQuantity
			 DbClassQuantity dbClassQuantity = new DbClassQuantity();
			 dbClassQuantity.setQuantity(quantity);
        	//              use populateEntity of DbClassQuantity
        	//              to populate the value quantityAvail
			 try {
				dbClassQuantity.readQuantityAvail(productParams[0]);
			} catch (DatabaseException e1) {
				e1.printStackTrace();
			}
			 IRules transferObject = new RulesQuantity(quantity);
			 try {
				transferObject.runRules();
			} catch (Exception e) {
				rulesOk=false;
				quantityWindow.setVisible(true);
				JOptionPane.showMessageDialog(quantityWindow, e.getMessage(),
						"Error", JOptionPane.ERROR_MESSAGE);
				
			} 
			
			if(rulesOk) {
				
				// save item on ItemCart
				String totalProce=Double.parseDouble(productParams[1])*Integer.parseInt(quantityWindow.getQuantityDesired())+"";
				
				IShoppingCartSubsystem shoppCart=ShoppingCartSubsystemFacade.getInstance();
				
					try{
						shoppCart.addCartItem(productParams[0], quantityWindow.getQuantityDesired(),totalProce, null);
						//System.out.println(productParams[0]+","+quantityWindow.getQuantityDesired()+","+totalProce+","+count);

					List<ICartItem> cartItem=shoppCart.getLiveCartItems();
					List<String[]> itemList=new ArrayList<String[]>();
					double cartTotalPrice=0.0;
					
					for(ICartItem cart:cartItem){
						System.out.println(cart);
						double unitPrice=Double.parseDouble(cart.getTotalprice())/Integer.parseInt(cart.getQuantity());
						itemList.add(new String[]{cart.getProductName(),cart.getQuantity(),unitPrice+"",cart.getTotalprice()});
						cartTotalPrice+=Double.parseDouble(cart.getTotalprice());
						//System.out.println(cart.getProductName()+","+cart.getQuantity()+","+cart.getTotalprice());
						
					}
					quantityWindow.dispose();
					cartItemsWindow = new CartItemsWindow();
					cartItemsWindow.updateModel(itemList);
					cartItemsWindow.setTotal(cartTotalPrice+"");
					
					}catch (Exception e) {
						System.out.println(e.getMessage());
						LOG.severe("Unable to Add Item to Cart: " + e.getMessage());
				    }
					
				
				
				EbazaarMainFrame.getInstance().getDesktop()
						.add(cartItemsWindow);
				cartItemsWindow.setVisible(true);
			}
		}
		
	}

	class BackToProductListListener implements ActionListener {
		public void actionPerformed(ActionEvent evt) {
			productDetailsWindow.setVisible(false);
			productListWindow.setVisible(true);
		}
	}

	// /// control CartItemsWindow

	class ContinueShoppingListener implements ActionListener {

		public void actionPerformed(ActionEvent evt) {
			cartItemsWindow.setVisible(false);

			// user has been looking at this product list
			if (productListWindow != null) {
				productListWindow.setVisible(true);
			}
			// user has just retrieved saved cart
			else {
				if (catalogListWindow != null) {
					catalogListWindow.dispose();
				}
				catalogListWindow = new CatalogListWindow();				
				EbazaarMainFrame.getInstance().getDesktop()
						.add(catalogListWindow);
				catalogListWindow.setVisible(true);
			}
		}
	}

	class SaveCartListener implements ActionListener {
		public void actionPerformed(ActionEvent evt) {
			
			// implement
			// here's the logic:
			// require login if not logged in
			SessionContext ctx = SessionContext.getInstance();
			Boolean loggedIn = (Boolean) ctx.get(CustomerConstants.LOGGED_IN);
			if (!loggedIn.booleanValue()) {
				LoginControl loginControl = new LoginControl(mainFrame, mainFrame);
				loginControl.startLogin();
				
			} else {
			// if current live cart does not have a cartid
			// then it's new;
			IShoppingCartSubsystem shoppingCart=ShoppingCartSubsystemFacade.getInstance();
			//shoppingCart.makeSavedCartLive();
			List<ICartItem> cartItems=shoppingCart.getLiveCartItems();
			/*
			for(ICartItem cartItem:cartItems){
				System.out.println(cartItem.getProductName());
				//System.out.println("Product Name:"+cartItem.getProductName()+",Product ID:"+cartItem.getProductid()+",CartID:"+cartItem.getCartid()+" ,Quantity:"+cartItem.getQuantity()+",Total Price:"+cartItem.getTotalprice()+",LineIT:"+cartItem.getLineitemid());
			}
			*/

			shoppingCart.saveLiveCart();
			
			
			// save cart level data, read the auto-generated
			// cart id, then loop
			
			// and get lineitemid's for each line, inserting
			// the relevant cartid, and save each
			// line
			
			// If current cart does have an id, we just save
			// cart items that are not flagged as "hasBeenSaved"
			// (a boolean in that class)
			
			// no need to save at the cart level, just save the
			// not-so-far-saved cart items
			
			// postcondition: the live cart has a cartid
			// and all cart items are flagged as "hasBeenSaved"
			}

		}
	}

	// /////// PUBLIC INTERFACE -- for getting instances of listeners ///
	// EbazaarMainFrame
	public ActionListener getNewOnlinePurchaseListener(EbazaarMainFrame f) {
		return (new PurchaseOnlineActionListener());
	}

	public LoginListener getLoginListener(EbazaarMainFrame f) {
		return new LoginListener();
	}

	public ActionListener getRetrieveCartActionListener(EbazaarMainFrame f) {
		return (new RetrieveCartActionListener());
	}

	// CatalogListWindow
	public ActionListener getSelectCatalogListener(CatalogListWindow w) {
		return new SelectCatalogListener();
	}

	public ActionListener getBackToMainFrameListener(CatalogListWindow w) {
		return new BackToMainFrameListener();
	}

	// ProductListWindow
	public ActionListener getSelectProductListener(ProductListWindow w,
			boolean useDefData) {
		return new SelectProductListener(useDefData);
	}

	public ActionListener getBackToCatalogListListener(ProductListWindow w) {
		return new BackToCatalogListListener();
	}

	// ProductDetails Window

	public ActionListener getAddToCartListener(ProductDetailsWindow w) {
		return new AddCartItemListener();
	}


	public ActionListener getBackToProductListListener(ProductDetailsWindow w) {
		return new BackToProductListListener();
	}

	// CartItemsWindow

	public ActionListener getContinueShoppingListener(CartItemsWindow w) {
		return (new ContinueShoppingListener());
	}

	public ActionListener getSaveCartListener(CartItemsWindow w) {
		return (new SaveCartListener());
	}

	public ActionListener getQuantityOkListener(QuantityWindow w, boolean edit,
			Integer posOfEdit) {
		return new QuantityOkListener();
	}

	// ////// PUBLIC ACCESSORS to register screens controlled by this class////

	public void setCatalogList(CatalogListWindow w) {
		catalogListWindow = w;
	}

	public void setMainFrame(EbazaarMainFrame m) {
		mainFrame = m;
	}

	public void setProductListWindow(ProductListWindow p) {
		productListWindow = p;
	}

	public void setProductDetailsWindow(ProductDetailsWindow p) {
		productDetailsWindow = p;
	}

	public void setCartItemsWindow(CartItemsWindow w) {
		cartItemsWindow = w;
	}

	public void setSelectOrderWindow(SelectOrderWindow w) {
		selectOrderWindow = w;
	}

	public void setMaintainCatalogTypes(MaintainCatalogTypes w) {
		maintainCatalogTypes = w;
	}

	public void setMaintainProductCatalog(MaintainProductCatalog w) {
		maintainProductCatalog = w;
	}

	public void setQuantityWindow(QuantityWindow w) {
		quantityWindow = w;
	}

	// private boolean edit;

	// ///// screens -- private references
	private EbazaarMainFrame mainFrame;
	private ProductListWindow productListWindow;
	private CatalogListWindow catalogListWindow;
	private ProductDetailsWindow productDetailsWindow;
	private CartItemsWindow cartItemsWindow;
	private SelectOrderWindow selectOrderWindow;
	private MaintainCatalogTypes maintainCatalogTypes;
	private MaintainProductCatalog maintainProductCatalog;
	private QuantityWindow quantityWindow;
	private Window[] allWindows = {};
	private JInternalFrame[] internalFrames = { productListWindow,
			catalogListWindow, productDetailsWindow, quantityWindow,
			cartItemsWindow, selectOrderWindow, maintainCatalogTypes,
			maintainProductCatalog };

	public void cleanUp() {
		ApplicationUtil.cleanup(allWindows);
		ApplicationUtil.cleanup(internalFrames);
	}

	// ///// make this class a singleton
	private static final BrowseAndSelectController instance = new BrowseAndSelectController();

	public static BrowseAndSelectController getInstance() {
		return instance;
	}

	private BrowseAndSelectController() {
	}

	// /////// communication with other controllers
	public void makeMainFrameVisible() {
		if (mainFrame == null) {
			mainFrame = new EbazaarMainFrame();
		}
		mainFrame.setVisible(true);
	}
}
